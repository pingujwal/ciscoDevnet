# DevNet Always-On Sandbox DNA Center
# https://devnetsandbox.cisco.com/RM/Diagram/Index/471eb739-323e-4805-b2a6-d0ec813dc8fc?diagramType=Topology
dnac = {
    "host": "sandboxdnac2.cisco.com",
    "username": "devnetuser",
    "password": "Cisco123!",
    "port": 443,
}


headers = {"content-type": "application/json", "x-auth-token": ""}
