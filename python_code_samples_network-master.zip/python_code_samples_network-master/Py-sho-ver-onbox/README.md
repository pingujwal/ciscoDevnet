# Python sho-ver

This is an example Python script that literally just does "show version" on a network element.

# requirements

-- IOS-XE running >/= 16.5 with guestshell enabled.

# running
-- on-box.
