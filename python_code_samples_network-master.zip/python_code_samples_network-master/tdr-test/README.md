# tdr-test

This is an example Python script that runs TDR test for every interface in an up status.

The output is thrown to screen, plus writte to a file in bootflash.

# requirements
-- IOS-XE running >/= 16.3.1 also enabled for GuestShell
-- 3850 Switches (TDR typically only works on Cat switches).

# running
-- Run onbox.