# RESTCONF get-serial-numbers

This is an example Python script that retrieves the serial numbers of IOS-XE devices and prints
each device with its collection of serial numbers.

# requirements
-- IOS-XE running >/= 16.3.1 also enabled for RESTCONF

# running
-- Can run on-box or off-box.
